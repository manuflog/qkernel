"""Q-Kernel: contextuality kernel extraction for Weyl/Pauli measurement programs."""

from .ir import WeylProgram, AnalysisResult, KernelResult
from .analyzer import analyze
from .optimizer import compress_min_odd_q

__all__ = [
    "WeylProgram",
    "AnalysisResult",
    "KernelResult",
    "analyze",
    "compress_min_odd_q",
]
