from __future__ import annotations

import json
from pathlib import Path

from .ir import WeylProgram


def load_program(path: str | Path) -> WeylProgram:
    data = json.loads(Path(path).read_text(encoding="utf-8"))

    d = int(data["d"])
    m = int(data["m"])
    observables = {name: tuple(int(x) for x in vec) for name, vec in data["observables"].items()}
    contexts = [list(context) for context in data["contexts"]]

    return WeylProgram(d=d, m=m, observables=observables, contexts=contexts)


def dump_program(program: WeylProgram, path: str | Path) -> None:
    data = {
        "d": program.d,
        "m": program.m,
        "observables": {name: list(vec) for name, vec in program.observables.items()},
        "contexts": program.contexts,
    }
    Path(path).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
