from __future__ import annotations

from itertools import combinations

from .carry import b_vector
from .gf2 import span
from .incidence import left_kernel_basis
from .ir import AnalysisResult, WeylProgram
from .symplectic import symplectic_int
from .validate import validate_program


def q_of_cycle(program: WeylProgram, lam: list[int]) -> int:
    """Compute aggregate Q(lambda) for a cycle.

    Individual inter-context pairings need not be divisible by d; the aggregate
    pairing is divisible by d on valid cycles.
    """
    multiset = []
    for bit, context in zip(lam, program.contexts):
        if bit:
            multiset.extend(program.observables[name] for name in context)

    total_pairing = 0
    for u, v in combinations(multiset, 2):
        total_pairing += symplectic_int(u, v)

    if total_pairing % program.d != 0:
        raise ValueError("cycle aggregate pairing is not divisible by d.")

    return (total_pairing // program.d) % 2


def analyze(program: WeylProgram) -> AnalysisResult:
    """Analyze contextuality using the odd-Q criterion.

    Currently implements the even-d state-independent Weyl-family criterion.
    """
    validate_program(program)

    if program.d % 2 != 0:
        return AnalysisResult(
            contextual=False,
            reason="Odd local dimension: this state-independent Weyl obstruction is zero in this criterion.",
            b_vector=[],
            cycle_basis=[],
            odd_cycle=None,
            q_value=None,
            selected_contexts=[],
        )

    b = b_vector(program)
    cycle_basis = left_kernel_basis(program)

    for lam in span(cycle_basis):
        dot = sum(x * y for x, y in zip(lam, b)) % 2
        q = q_of_cycle(program, lam)
        if dot != q:
            raise AssertionError("internal check failed: b^T lambda != Q(lambda).")

        if q == 1:
            selected = [i for i, bit in enumerate(lam) if bit]
            return AnalysisResult(
                contextual=True,
                reason="odd-Q cycle found",
                b_vector=b,
                cycle_basis=cycle_basis,
                odd_cycle=lam,
                q_value=q,
                selected_contexts=selected,
            )

    return AnalysisResult(
        contextual=False,
        reason="no odd-Q cycle found",
        b_vector=b,
        cycle_basis=cycle_basis,
        odd_cycle=None,
        q_value=None,
        selected_contexts=[],
    )
