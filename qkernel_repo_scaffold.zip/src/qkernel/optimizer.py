from __future__ import annotations

from .analyzer import q_of_cycle
from .gf2 import span
from .incidence import left_kernel_basis
from .ir import KernelResult, WeylProgram
from .validate import validate_program


def compress_min_odd_q(program: WeylProgram) -> KernelResult:
    """Find the minimum-size odd-Q contextual kernel.

    This solves the POC version of:

        minimize |lambda|
        subject to A^T lambda = 0 mod 2
                   b^T lambda = Q(lambda) = 1 mod 2

    Current implementation brute-forces the cycle span and is intended for
    examples and small/medium proofs of concept.
    """
    validate_program(program)

    if program.d % 2 != 0:
        return _empty(program)

    cycle_basis = left_kernel_basis(program)

    best: tuple[tuple[int, int], list[int], list[str], int] | None = None

    for lam in span(cycle_basis):
        q = q_of_cycle(program, lam)
        if q != 1:
            continue

        selected_contexts = [i for i, bit in enumerate(lam) if bit]
        selected_observables = sorted(
            {name for i in selected_contexts for name in program.contexts[i]}
        )
        score = (len(selected_contexts), len(selected_observables))

        if best is None or score < best[0]:
            best = (score, selected_contexts, selected_observables, q)

    if best is None:
        return _empty(program)

    _, selected_contexts, selected_observables, q = best
    return KernelResult(
        contextual=True,
        original_contexts=len(program.contexts),
        original_observables=len(program.observables),
        compressed_contexts=len(selected_contexts),
        compressed_observables=len(selected_observables),
        selected_contexts=selected_contexts,
        selected_observables=selected_observables,
        q_value=q,
        compression_ratio_contexts=len(program.contexts) / len(selected_contexts),
        compression_ratio_observables=len(program.observables) / len(selected_observables),
    )


def _empty(program: WeylProgram) -> KernelResult:
    return KernelResult(
        contextual=False,
        original_contexts=len(program.contexts),
        original_observables=len(program.observables),
        compressed_contexts=0,
        compressed_observables=0,
        selected_contexts=[],
        selected_observables=[],
        q_value=None,
        compression_ratio_contexts=0.0,
        compression_ratio_observables=0.0,
    )
