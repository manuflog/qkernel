from __future__ import annotations

import argparse

from .analyzer import analyze
from .certificate import kernel_to_json, kernel_to_markdown
from .io import load_program
from .optimizer import compress_min_odd_q


def main() -> None:
    parser = argparse.ArgumentParser(prog="qkernel")
    sub = parser.add_subparsers(dest="command", required=True)

    analyze_cmd = sub.add_parser("analyze", help="detect odd-Q contextuality")
    analyze_cmd.add_argument("path")

    compress_cmd = sub.add_parser("compress", help="extract a minimal odd-Q kernel")
    compress_cmd.add_argument("path")
    compress_cmd.add_argument("--json", action="store_true", help="print JSON certificate")

    args = parser.parse_args()
    program = load_program(args.path)

    if args.command == "analyze":
        result = analyze(program)
        print(f"contextual: {result.contextual}")
        print(f"reason: {result.reason}")
        print(f"b_vector: {result.b_vector}")
        print(f"cycle_basis_dimension: {len(result.cycle_basis)}")
        print(f"q_value: {result.q_value}")
        print(f"selected_contexts: {result.selected_contexts}")

    elif args.command == "compress":
        kernel = compress_min_odd_q(program)
        if args.json:
            print(kernel_to_json(program, kernel))
        else:
            print(kernel_to_markdown(program, kernel))
