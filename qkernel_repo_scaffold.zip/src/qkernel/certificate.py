from __future__ import annotations

import json

from .ir import KernelResult, WeylProgram


def kernel_to_json(program: WeylProgram, kernel: KernelResult) -> str:
    """Machine-readable contextual kernel certificate."""
    payload = {
        "contextual": kernel.contextual,
        "d": program.d,
        "m": program.m,
        "q_value": kernel.q_value,
        "selected_contexts": kernel.selected_contexts,
        "selected_observables": kernel.selected_observables,
        "compression": {
            "contexts_original": kernel.original_contexts,
            "contexts_kernel": kernel.compressed_contexts,
            "observables_original": kernel.original_observables,
            "observables_kernel": kernel.compressed_observables,
            "context_ratio": kernel.compression_ratio_contexts,
            "observable_ratio": kernel.compression_ratio_observables,
        },
    }
    return json.dumps(payload, indent=2)


def kernel_to_markdown(program: WeylProgram, kernel: KernelResult) -> str:
    if not kernel.contextual:
        return "## Q-Kernel Certificate\n\nNo odd-Q contextual kernel found.\n"

    lines = [
        "## Q-Kernel Certificate",
        "",
        f"- local dimension `d`: {program.d}",
        f"- qudits `m`: {program.m}",
        f"- Q value: `{kernel.q_value}`",
        f"- selected contexts: `{kernel.selected_contexts}`",
        f"- context compression: `{kernel.compression_ratio_contexts:.2f}x`",
        f"- observable compression: `{kernel.compression_ratio_observables:.2f}x`",
        "",
        "### Contexts",
        "",
    ]

    for idx in kernel.selected_contexts:
        lines.append(f"- `C{idx}`: `{program.contexts[idx]}`")

    lines.append("")
    lines.append("Each selected observable appears with even multiplicity across the selected contexts,")
    lines.append("while the aggregate commutator-carry has odd parity. Therefore no global")
    lines.append("noncontextual value assignment exists for this kernel.")
    lines.append("")

    return "\n".join(lines)
