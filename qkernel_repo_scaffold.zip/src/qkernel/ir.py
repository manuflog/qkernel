from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

Vector = Tuple[int, ...]
Context = List[str]


@dataclass(frozen=True)
class WeylProgram:
    """Internal representation of a Weyl/Pauli measurement program.

    Observables are vectors in Z_d^(2m), using interleaved coordinates:

        [z1, x1, z2, x2, ..., zm, xm]

    Contexts are lists of observable names.
    """

    d: int
    m: int
    observables: Dict[str, Vector]
    contexts: List[Context]


@dataclass(frozen=True)
class AnalysisResult:
    contextual: bool
    reason: str
    b_vector: List[int]
    cycle_basis: List[List[int]]
    odd_cycle: Optional[List[int]]
    q_value: Optional[int]
    selected_contexts: List[int]


@dataclass(frozen=True)
class KernelResult:
    contextual: bool
    original_contexts: int
    original_observables: int
    compressed_contexts: int
    compressed_observables: int
    selected_contexts: List[int]
    selected_observables: List[str]
    q_value: Optional[int]
    compression_ratio_contexts: float
    compression_ratio_observables: float
