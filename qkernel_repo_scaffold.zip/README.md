# Q-Kernel

**Q-Kernel** is an experimental Python library for contextuality kernel extraction in Weyl/Pauli measurement programs.

It implements the binary-linear-algebra core behind the odd-\(Q\) criterion:

\[
F \text{ contextual}
\iff
\exists \lambda,\quad A^T\lambda=0 \pmod 2,\quad b^T\lambda=1 \pmod 2.
\]

Engineering interpretation:

> Given a large Weyl/Pauli measurement program, find the smallest closed parity cycle of contexts carrying an odd commutator-carry obstruction — the irreducible contextual kernel.

## What this is

A narrow, testable compiler-analysis backend:

- validate Weyl/Pauli context families;
- compute commutator-carry bits \(b(C)\);
- build the context-observable incidence matrix \(A\);
- find parity cycles \(A^T\lambda=0\);
- detect odd-\(Q\) contextuality;
- compress a large program to a minimal odd-\(Q\) certificate.

## What this is not yet

This is **not yet** a T-count optimizer or a full quantum compiler. The first target is a rigorous contextuality kernelizer. Later modules can connect the kernel size/rank to magic-state overhead, resource estimation, and qudit compiler passes.

## Install locally

```bash
pip install -e ".[dev]"
```

## CLI examples

```bash
qkernel analyze examples/peres_mermin.json
qkernel compress examples/noisy_pm.json
```

Expected behavior:

- `peres_mermin.json` is contextual;
- `noisy_pm.json` compresses many irrelevant contexts to the six-context Peres-Mermin kernel.

## Python API

```python
from qkernel.io import load_program
from qkernel.analyzer import analyze
from qkernel.optimizer import compress_min_odd_q

program = load_program("examples/peres_mermin.json")
result = analyze(program)
kernel = compress_min_odd_q(program)

print(result.contextual)
print(kernel.selected_contexts)
```

## Core theorem implemented

For even local dimension \(d\), contexts are finite commuting Weyl families whose labels sum to zero mod \(d\). For each context,

\[
b(C)=\sum_{i<j}\langle c_i,c_j\rangle/d \pmod 2.
\]

For a cycle \(\lambda\) in the left kernel of the incidence matrix,

\[
A^T\lambda=0,
\]

the odd-\(Q\) obstruction is detected by

\[
b^T\lambda = Q(\lambda) = 1.
\]

The key implementation rule is:

> Do **not** reduce the symplectic pairing modulo \(d\) before dividing by \(d\). The carry is an integer lift.

## Roadmap

1. Core library and CLI.
2. Certificate renderer.
3. Qiskit / Stim / Pauli-string adapters.
4. Minimum-weight odd-\(Q\) optimization beyond brute-force cycle enumeration.
5. Resource-estimator experiments comparing kernel features to T-count, T-depth, magic injections, and stabilizer rank.
6. Qudit-specific demos for even \(d=4,6,8\).
